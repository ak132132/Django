from django.db import models
from django.forms import ModelForm
# Create your models here.

class Events(models.Model):

    etype = models.CharField(max_length=100)
    ename = models.CharField(max_length=100)
    desc = models.TextField()
    price = models.IntegerField()
    img = models.ImageField(upload_to=None,default="")
    def __str__(self):
        return self.ename
    
class contact(models.Model):
    Name = models.CharField(max_length=100)
    Email = models.CharField(max_length=100)
    Message = models.TextField()
    def __str__(self):
        return self.Name
  