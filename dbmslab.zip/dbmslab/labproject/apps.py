from django.apps import AppConfig


class LabprojectConfig(AppConfig):
    name = 'labproject'
