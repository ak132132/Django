from django.shortcuts import render
from .models import Events
from django.views.generic import View
from django.http import HttpResponse 

from .forms import ContactForm 
from django.contrib.auth.models import User,auth
# Create your views here.

def index(request):
    
    return render(request,'index.html')

def events(request):
   
    events = Events.objects.all()

    return render(request,'events.html',{'events' : events })

def contact(request):
    if request.method =='POST':
        form = ContactForm(data=request.POST)
        if form.is_valid():

            form.save()
            return HttpResponse('<h1> Submission successfull </h1>')
        
    else:
        form = ContactForm()
        return render(request,'contact.html',{'form':form})

