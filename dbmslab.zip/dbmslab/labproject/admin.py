from django.contrib import admin
from .models import Events,contact
# Register your models here.

admin.site.register(Events)
admin.site.register(contact)