from django.contrib import admin
from accounts.models import Reginfo, User,Events
from labproject.models import Events


# Register your models here.
admin.site.register(Reginfo)

