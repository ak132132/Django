from django.db import models
from labproject.models import Events
from django.contrib.auth.models import User

# Create your models here.

class Reginfo(models.Model):
    user = models.OneToOneField(User,on_delete=models.CASCADE)
    Event_Name = models.ForeignKey('labproject.Events' , on_delete=models.CASCADE,related_name='reginfo_event_name',default=0)
    
     #addtional field

    Phone_no = models.CharField(max_length=10)
    
    def __str__(self):
        return self.user.username
