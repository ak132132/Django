from django.shortcuts import render,redirect

#from .forms import SignUpForm
from django.contrib.auth.models import User,auth
from accounts.forms import UserForm,UserProfileInfoForm
from django.contrib.auth import login, authenticate
from django.http import HttpResponseRedirect, HttpResponse
from django.urls import reverse
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required

# Create your views here.
@login_required
def user_logout(request):
    logout(request)
    return HttpResponseRedirect('/')

def user_login(request):

    if request.method == 'POST':
        # First get the username and password supplied
        username = request.POST.get('username')
        password = request.POST.get('password')

        # Django's built-in authentication function:
        user = authenticate(username=username, password=password)

        # If we have a user
        if user:
            #Check it the account is active
            if user.is_active:
                # Log the user in.
                auth.login(request,user)
                # Send the user back to some page.
                # In this case their homepage.
                return HttpResponseRedirect('/')
            else:
                # If account is not active:
                return HttpResponse("Your account is not active.")
        else:
            print("Someone tried to login and failed.")
            print("They used username: {} and password: {}".format(username,password))
            return HttpResponse("<h1>Invalid login details supplied.</h1>")

    else:
        #Nothing has been provided for username or password.
        return render(request, 'login.html', {})




def register(request):

    registered = False

    if request.method == 'POST':

        # Get info from "both" forms
        # It appears as one form to the user on the .html page
        user_form = UserForm(data=request.POST)
        profile_form = UserProfileInfoForm(data=request.POST)

        # Check to see both forms are valid
        if user_form.is_valid() and profile_form.is_valid():

            # Save User Form to Database
            user = user_form.save()

            # Hash the password
            user.set_password(user.password)

            # Update with Hashed password
            user.save()

            # Now we deal with the extra info!

            # Can't commit yet because we still need to manipulate
            profile = profile_form.save(commit=False)

            # Set One to One relationship between
            # UserForm and UserProfileInfoForm
            profile.user = user



            # Now save model
            profile.save()

            # Registration Successful!
            registered = True
            return HttpResponse('<h1>Registration successfull</h1>')
            return redirect('accounts/login')
            

        else:
            # One of the forms was invalid if this else gets called.
            print(user_form.errors,profile_form.errors)


    else:
        # Was not an HTTP post so we just render the forms as blank.
        user_form = UserForm()
        profile_form = UserProfileInfoForm()
            
       

    # This is the render and context dictionary to feed
    # back to the registration.html file page.
   
    return render(request,'register.html',
                          {'user_form':user_form,
                           'profile_form':profile_form,
                           'registered':registered})

  

@login_required
def profile(request):
    return render(request,'profile.html')        
    
   

         

